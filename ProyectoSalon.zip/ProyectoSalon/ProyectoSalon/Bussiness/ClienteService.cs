﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using proyecto_salon.Services;
using ProyectoSalon.Helpers;
using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Bussiness
{
    public class ClienteService : IClienteService
    {
        private const string PURPOSE = "ClienteProtection";
        private readonly ILogger<ClienteService> _looger;
        private readonly salonContext _context;
        private readonly IDataProtector _protector;
        private readonly JwtSettings _jwtSettings;


        public ClienteService(ILogger<ClienteService> logger, salonContext context, IDataProtectionProvider provider, IOptions<JwtSettings> options)
        {
            _context = context;
            _looger = logger;
            _jwtSettings = options.Value;
            _protector = provider.CreateProtector(PURPOSE);
        }


        //ver todos
        public IEnumerable GetAll(int index = 0, int take = 50)
        {
            try
            {
                _looger.LogInformation($"Informacion de cliente de {index} a {take}");

                return _context.Clientes.Skip(index).Take(take).Select(e => new {
                    Id_cliente = e.IdCliente,
                    Nomb_cliente = e.NombCliente,
                    App_cliente= e.AppCliente,
                    Tel_cliente = e.TelCliente,
                    Correo_cliente = e.CorreoCliente,
                    Novisitas = e.NoVisitas,
                    Norecomp = e.NoRecomp
                }).OrderBy(e => e.Nomb_cliente);
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetAll)}", new { index, take });
                throw;
            }
        }



        //ver determinado cliente 
        public Cliente GetCliente(int idCliente)
        {

            try
            {
                _looger.LogInformation($"teniendo informacion del cliente numero {idCliente}");
                return _context.Clientes.Where(e => e.IdCliente == idCliente).FirstOrDefault();
            } 
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetCliente)}", new { idCliente});
                throw;
            }
        }


        //agregar cliente
        public bool GuardarCliente(Cliente cliente)
        {
            try
            {
                _looger.LogInformation($"Agregando nuevo cliente a la base de datos");
                _context.Clientes.Add(cliente);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GuardarCliente)}", new { cliente });
                throw;
            }
        }


        //actualizar cliente 
        public bool ActualizarCliente(Cliente cliente, int idCliente)
        {
            try
            {
                _looger.LogInformation($"Actualizando cliente con numero {idCliente}");
                var guardarcli = _context.Clientes.Where(e => e.IdCliente == idCliente).FirstOrDefault();

                if (guardarcli != null)
                {

                    guardarcli.IdCliente = cliente.IdCliente;
                    guardarcli.NombCliente = !guardarcli.NombCliente.Equals(cliente.NombCliente) ? cliente.NombCliente : guardarcli.NombCliente;
                    guardarcli.AppCliente = !guardarcli.AppCliente.Equals(cliente.AppCliente) ? cliente.AppCliente : guardarcli.AppCliente;
                    guardarcli.TelCliente = cliente.TelCliente;
                    guardarcli.CorreoCliente = cliente.CorreoCliente;
                    guardarcli.NoVisitas = cliente.NoVisitas;
                    guardarcli.NoRecomp = cliente.NoRecomp;

                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarCliente)}", new { idCliente, cliente });
                throw;
            }
        }


        public bool ActualizarRecomp(Cliente cliente, int idCliente)
        {
            try
            {
                _looger.LogInformation($"Actualizando cliente con numero {idCliente}");
                var guardarcli = _context.Clientes.Where(e => e.IdCliente == idCliente).FirstOrDefault();

                if (guardarcli != null)
                {

                    guardarcli.IdCliente = cliente.IdCliente;
                    guardarcli.NombCliente = !guardarcli.NombCliente.Equals(cliente.NombCliente) ? cliente.NombCliente : guardarcli.NombCliente;
                    guardarcli.AppCliente = !guardarcli.AppCliente.Equals(cliente.AppCliente) ? cliente.AppCliente : guardarcli.AppCliente;
                    guardarcli.TelCliente = cliente.TelCliente;
                    guardarcli.CorreoCliente = cliente.CorreoCliente;
                    guardarcli.NoVisitas = cliente.NoVisitas;
                    guardarcli.NoRecomp = cliente.NoRecomp;

                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarRecomp)}", new { idCliente, cliente });
                throw;
            }
        }


    }
}
