﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using ProyectoSalon.Helpers;
using ProyectoSalon.Models;
using ProyectoSalon.Services;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;

namespace ProyectoSalon.Bussiness
{
    public class EmpleadoService : IEmpleadoService
    {
        private const string PURPOSE = "EmpleadoProtection";
        private readonly ILogger<EmpleadoService> _looger;
        private readonly salonContext _context;
        private readonly IDataProtector _protector;
        private readonly JwtSettings _jwtSettings;


        public EmpleadoService(ILogger<EmpleadoService> logger, salonContext context, IDataProtectionProvider provider, IOptions<JwtSettings> options)
        {
            _context = context;
            _looger = logger;
            _jwtSettings = options.Value;
            _protector = provider.CreateProtector(PURPOSE);
        }


        //ver todos
        public IEnumerable GetAll(int index = 0, int take = 50)
        {
            try
            {
                _looger.LogInformation($"Informacion de empleado de {index} a {take}");

                return _context.Empleados.Skip (index).Take (take).Select (e => new {
                    Id_emp  = e.IdEmp,
                    Nomb_emp  = e.NombEmp,
                    App_emp  = e.AppEmp,
                    Tel_emp  = e.TelEmp,
                    Correo_emp  = e.CorreoEmp,
                    Contrasena = e.Contrasena,
                    Fecha_ing  = e.FechaIng,
                    Estatus = e.Estatus
                }).OrderBy(e => e.Nomb_emp);
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetAll)}", new { index, take });
                throw;
            }
        }



        //ver determinado empleado 
        public Empleado GetEmpleado(int idEmp)
        {
            
            try
            {
                _looger.LogInformation($"teniendo informacion del empleado numero {idEmp}");
                return _context.Empleados.Where(e => e.IdEmp == idEmp).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetEmpleado)}", new { idEmp });
                throw;
            }
        }


        //agregar empleado
        public bool GuardarEmpleado(Empleado empleado)
        {
            try
            {
                _looger.LogInformation($"Agregando nuevo empleado a la base de datos");
                _context.Empleados.Add(empleado);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GuardarEmpleado)}", new { empleado });
                throw;
            }
        }


        //actualizar empleado 
        public bool ActualizarEmpleado( Empleado empleado, int idEmp)
        { 
            try
            {
                _looger.LogInformation($"Actualizando empleado con numero {idEmp}");
                var guardaremp = _context.Empleados.Where(e => e.IdEmp == idEmp).FirstOrDefault();

                if (guardaremp != null)
                {

                    guardaremp.IdEmp = empleado.IdEmp;
                    guardaremp.NombEmp = !guardaremp.NombEmp.Equals(empleado.NombEmp) ? empleado.NombEmp : guardaremp.NombEmp;
                    guardaremp.AppEmp = !guardaremp.AppEmp.Equals(empleado.AppEmp) ? empleado.AppEmp : guardaremp.AppEmp;
                    guardaremp.TelEmp = empleado.TelEmp;
                    guardaremp.CorreoEmp = empleado.CorreoEmp;
                    guardaremp.Contrasena = empleado.Contrasena;
                    guardaremp.FechaIng = empleado.FechaIng;
                    guardaremp.Estatus = empleado.Estatus;
                    
                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarEmpleado)}", new { idEmp , empleado });
                throw;
            }
        }

        public bool ActualizarEst(Empleado empleado, int idEmp)
        {
            try
            {
                _looger.LogInformation($"Actualizando estatus de empleado {idEmp}");
                var guardaremp = _context.Empleados.Where(e => e.IdEmp == idEmp).FirstOrDefault();

                if (guardaremp != null)
                {

                    guardaremp.IdEmp = empleado.IdEmp;
                    guardaremp.NombEmp = !guardaremp.NombEmp.Equals(empleado.NombEmp) ? empleado.NombEmp : guardaremp.NombEmp;
                    guardaremp.AppEmp = !guardaremp.AppEmp.Equals(empleado.AppEmp) ? empleado.AppEmp : guardaremp.AppEmp;
                    guardaremp.TelEmp = empleado.TelEmp;
                    guardaremp.CorreoEmp = empleado.CorreoEmp;
                    guardaremp.Contrasena = empleado.Contrasena;
                    guardaremp.FechaIng = empleado.FechaIng;
                    guardaremp.Estatus = empleado.Estatus;

                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarEst)}", new { idEmp, empleado });
                throw;
            }
        }




    }
}
