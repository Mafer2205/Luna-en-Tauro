﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using ProyectoSalon.Helpers;
using ProyectoSalon.Models;
using ProyectoSalon.Services;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ProyectoSalon.Bussiness
{
    public class UserService : IUserService
    {
        private List<User> _users = new List<User>()
        {
            new User ()
            {
                Id = "1",
                FirstName = "Fernanda",
                LastName = "Garcia",
                UserName = "administrador",
                Password = "1234",
                Token = ""
            },
        };

        private readonly JwtSettings _jwtSettings;

        public UserService(IOptions<JwtSettings> options)
        {
            _jwtSettings = options.Value;
        }

        public User Authenticate(string username, string password)
        {
            var user = _users.SingleOrDefault(u => u.UserName == username && u.Password == password);
            if (user == null) return user;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = System.Text.Encoding.ASCII.GetBytes(_jwtSettings.Secret);

            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(
                    new Claim[] {
                        new Claim (ClaimTypes.Name, user.UserName)
                    }
                ),
                Expires = DateTime.Now.AddHours(1),
                NotBefore = DateTime.Now,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            user.Token = tokenHandler.WriteToken(token);
            //user.Password = null;

            return user;
        }

        public IEnumerable<User> GetAll()
        {
            return _users.Select(u => {
                u.Password = "";
                return u;
            });
        }
    }
}