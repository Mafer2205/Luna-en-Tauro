﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using proyecto_salon.Services;
using ProyectoSalon.Helpers;
using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Bussiness
{

    public class CitaService : ICitaService
    {
        private const string PURPOSE = "CitaProtection";
        private readonly ILogger<CitaService> _looger;
        private readonly salonContext _context;
        private readonly IDataProtector _protector;
        private readonly JwtSettings _jwtSettings;


        public CitaService(ILogger<CitaService> logger, salonContext context, IDataProtectionProvider provider, IOptions<JwtSettings> options)
        {
            _context = context;
            _looger = logger;
            _jwtSettings = options.Value;
            _protector = provider.CreateProtector(PURPOSE);
        }


        //ver todos
        public IEnumerable GetAll(int index = 0, int take = 50)
        {
            try
            {
                _looger.LogInformation($"Informacion de cita de {index} a {take}");

                return _context.Citas.Skip(index).Take(take).Select(e => new {
                    Id_cita = e.IdCita,
                    Fecha_cita = e.FechaCita,
                    Asistio = e.Asistio,
                    RCliente = e.RCliente,
                    RServ = e.RServ,
                    RPromo = e.RPromo,
                    REmp = e.REmp,
                    TotalCita = e.TotalCita

                }).OrderBy(e => e.Fecha_cita);
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetAll)}", new { index, take });
                throw;
            }
        }


        public IEnumerable Getb(int index = 0, int take = 20)
        {

            try
            {
                _looger.LogInformation($"teniendo informacion de servicios y sus citas");
                return _context.Citas.Skip(index).Take(take).Where(e => e.Asistio == "Si").Join(_context.Servicios, e => e.RServ, ec => ec.IdServ, (e, ec) => new
                {
                   Fecha = e.FechaCita,
                   Nomb_serv =  ec.NombServ
                });
 
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(Getb)}");
                throw;
            }
        }

        public IEnumerable Getemp(int index = 0, int take = 20)
        {

            try
            {
                _looger.LogInformation($"teniendo informacion de empleados y citas");
                return _context.Citas.Skip(index).Take(take).Where(e => e.Asistio == "Si").Join(_context.Empleados, e => e.REmp, ec => ec.IdEmp, (e, ec) => new
                {
                    Nomb_emp = ec.NombEmp,
                    App_emp = ec.AppEmp,
                    Fecha = e.FechaCita,
                    Total_cita = e.TotalCita
                });

            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(Getemp)}");
                throw;
            }
        }




        //ver determinada cita
        public Cita GetCita(int idCita)
        {

            try
            {
                _looger.LogInformation($"teniendo informacion de la cita numero {idCita}");
                return _context.Citas.Where(e => e.IdCita == idCita).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetCita)}", new { idCita });
                throw;
            }
        }


        //agregar cita
        public bool GuardarCita(Cita cita)
        {
            try
            {
                _looger.LogInformation($"Agregando nueva cita a la base de datos");
                _context.Citas.Add(cita);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GuardarCita)}", new { cita });
                throw;
            }
        }


        //actualizar cita
        public bool ActualizarCita(Cita cita, int idCita)
        {
            try
            {
                _looger.LogInformation($"Actualizando cita con numero {idCita}");
                var guardarcita = _context.Citas.Where(e => e.IdCita == idCita).FirstOrDefault();

                if (guardarcita != null)
                {

                    guardarcita.IdCita = cita.IdCita;
                    guardarcita.FechaCita = cita.FechaCita;
                    guardarcita.Asistio = cita.Asistio;
                    guardarcita.RCliente = cita.RCliente;
                    guardarcita.RServ = cita.RServ;
                    guardarcita.RPromo = cita.RPromo;
                    guardarcita.REmp = cita.RPromo;
                    guardarcita.TotalCita = cita.TotalCita;

                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarCita)}", new { idCita, cita });
                throw;
            }
        }

        public bool ActualizarE(Cita cita, int idCita)
        {
            try
            {
                _looger.LogInformation($"Actualizando estatus de cita {idCita}");
                var guardarcita = _context.Citas.Where(e => e.IdCita == idCita).FirstOrDefault();

                if (guardarcita != null)
                {

                    guardarcita.IdCita = cita.IdCita;
                    guardarcita.FechaCita = cita.FechaCita;
                    guardarcita.Asistio = cita.Asistio;
                    guardarcita.RCliente = cita.RCliente;
                    guardarcita.RServ = cita.RServ;
                    guardarcita.RPromo = cita.RPromo;
                    guardarcita.REmp = cita.RPromo;
                    guardarcita.TotalCita = cita.TotalCita;

                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarE)}", new { idCita, cita });
                throw;
            }
        }

    }
}
