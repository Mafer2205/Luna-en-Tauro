﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using proyecto_salon.Services;
using ProyectoSalon.Helpers;
using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Bussiness
{
    public class PromocioneService : IPromocioneService
    {
        private const string PURPOSE = "PromocioneProtection";
        private readonly ILogger<PromocioneService> _looger;
        private readonly salonContext _context;
        private readonly IDataProtector _protector;
        private readonly JwtSettings _jwtSettings;


        public PromocioneService(ILogger<PromocioneService> logger, salonContext context, IDataProtectionProvider provider, IOptions<JwtSettings> options)
        {
            _context = context;
            _looger = logger;
            _jwtSettings = options.Value;
            _protector = provider.CreateProtector(PURPOSE);
        }


        //ver todos
        public IEnumerable GetAll(int index = 0, int take = 50)
        {
            try
            {
                _looger.LogInformation($"Informacion de promocion de {index} a {take}");

                return _context.Promociones.Skip(index).Take(take).Select(e => new {
                    Id_promo = e.IdPromo,
                    Nomb_promo = e.NombPromo,
                    Descrip_promo = e.DescripPromo,
                    Fecha_promo = e.FechaPromo,
                    Descuento = e.Descuento
                }).OrderBy(e => e.Fecha_promo);
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetAll)}", new { index, take });
                throw;
            }
        }



        //ver determinada promocion
        public Promocione GetPromocione(int idPromo)
        {

            try
            {
                _looger.LogInformation($"teniendo informacion de la promocion numero {idPromo}");
                return _context.Promociones.Where(e => e.IdPromo == idPromo).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetPromocione)}", new { idPromo });
                throw;
            }
        }


        //agregar promocion
        public bool GuardarPromocione(Promocione promocione)
        {
            try
            {
                _looger.LogInformation($"Agregando nueva promocion a la base de datos");
                _context.Promociones.Add(promocione);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GuardarPromocione)}", new { promocione });
                throw;
            }
        }
    }
}
