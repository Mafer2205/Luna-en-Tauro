﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using proyecto_salon.Services;
using ProyectoSalon.Helpers;
using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Bussiness
{
    public class ServicioService : IServicioService
    {
        private const string PURPOSE = "ServicioProtection";
        private readonly ILogger<ServicioService> _looger;
        private readonly salonContext _context;
        private readonly IDataProtector _protector;
        private readonly JwtSettings _jwtSettings;


        public ServicioService(ILogger<ServicioService> logger, salonContext context, IDataProtectionProvider provider, IOptions<JwtSettings> options)
        {
            _context = context;
            _looger = logger;
            _jwtSettings = options.Value;
            _protector = provider.CreateProtector(PURPOSE);
        }



        //ver todos
        public IEnumerable GetAll(int index = 0, int take = 50)
        {
            try
            {
                _looger.LogInformation($"Informacion de servicio de {index} a {take}");

                return _context.Servicios.Skip(index).Take(take).Select(e => new {
                    Id_serv = e.IdServ,
                    Nomb_serv = e.NombServ,
                    Descrip_serv = e.DescripServ,
                    Costo_serv = e.CostoServ
                });
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetAll)}", new { index, take });
                throw;
            }
        }


        //ver determinado servicio
        public Servicio GetServicio(int idServ)
        {

            try
            {
                _looger.LogInformation($"teniendo informacion del servicio numero {idServ}");
                return _context.Servicios.Where(e => e.IdServ == idServ).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GetServicio)}", new { idServ});
                throw;
            }
        }


        //agregar servicio
        public bool GuardarServicio(Servicio servicio)
        {
            try
            {
                _looger.LogInformation($"Agregando nuevo servicio a la base de datos");
                _context.Servicios.Add(servicio);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(GuardarServicio)}", new { servicio });
                throw;
            }
        }


        //actualizar servicio
        public bool ActualizarServicio(Servicio servicio, int idServ)
        {
            try
            {
                _looger.LogInformation($"Actualizando servicio con numero {idServ}");
                var guardarserv = _context.Servicios.Where(e => e.IdServ == idServ).FirstOrDefault();

                if (guardarserv != null)
                {

                    guardarserv.IdServ = servicio.IdServ;
                    guardarserv.NombServ = !guardarserv.NombServ.Equals(servicio.NombServ) ? servicio.NombServ : guardarserv.NombServ;
                    guardarserv.DescripServ= !guardarserv.DescripServ.Equals(servicio.DescripServ) ? servicio.DescripServ : guardarserv.DescripServ;
                    guardarserv.CostoServ = servicio.CostoServ;

                    _context.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                _looger.LogError(ex, $"Un error ocurrio en el metodo {nameof(ActualizarServicio)}", new { idServ, servicio });
                throw;
            }
        }


    }
}
