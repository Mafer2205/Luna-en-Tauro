﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProyectoSalon.Models
{
    public partial class Servicio
    {
        public Servicio()
        {
            Cita = new HashSet<Cita>();
        }

        public int IdServ { get; set; }
        public string NombServ { get; set; }
        public string DescripServ { get; set; }
        public float CostoServ { get; set; }

        public virtual ICollection<Cita> Cita { get; set; }
    }
}
