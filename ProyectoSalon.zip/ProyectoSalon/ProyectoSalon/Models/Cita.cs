﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProyectoSalon.Models
{
    public partial class Cita
    {
        public int IdCita { get; set; }
        public DateTime FechaCita { get; set; }
        public string Asistio { get; set; }
        public int RCliente { get; set; }
        public int RServ { get; set; }
        public int RPromo { get; set; }
        public int REmp { get; set; }
        public float TotalCita { get; set; }

        public virtual Cliente RClienteNavigation { get; set; }
        public virtual Empleado REmpNavigation { get; set; }
        public virtual Promocione RPromoNavigation { get; set; }
        public virtual Servicio RServNavigation { get; set; }
    }
}
