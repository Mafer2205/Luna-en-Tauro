﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace ProyectoSalon.Models
{
    public partial class salonContext : DbContext
    {
        public salonContext()
        {
        }

        public salonContext(DbContextOptions<salonContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cita> Citas { get; set; }
        public virtual DbSet<Cliente> Clientes { get; set; }
        public virtual DbSet<Empleado> Empleados { get; set; }
        public virtual DbSet<Promocione> Promociones { get; set; }
        public virtual DbSet<Servicio> Servicios { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseMySql("server=localhost;port=3306;user=root;password=divergente;database=salon", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.26-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasCharSet("utf8")
                .UseCollation("utf8_general_ci");

            modelBuilder.Entity<Cita>(entity =>
            {
                entity.HasKey(e => e.IdCita)
                    .HasName("PRIMARY");

                entity.ToTable("citas");

                entity.HasIndex(e => e.RCliente, "R_cliente_idx");

                entity.HasIndex(e => e.REmp, "R_emp_idx");

                entity.HasIndex(e => e.RPromo, "R_promo_idx");

                entity.HasIndex(e => e.RServ, "R_serv_idx");

                entity.Property(e => e.IdCita).HasColumnName("Id_cita");

                entity.Property(e => e.Asistio)
                    .IsRequired()
                    .HasMaxLength(5);

                entity.Property(e => e.FechaCita)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_cita");

                entity.Property(e => e.RCliente).HasColumnName("R_cliente");

                entity.Property(e => e.REmp).HasColumnName("R_emp");

                entity.Property(e => e.RPromo).HasColumnName("R_promo");

                entity.Property(e => e.RServ).HasColumnName("R_serv");

                entity.Property(e => e.TotalCita).HasColumnName("Total_cita");

                entity.HasOne(d => d.RClienteNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.RCliente)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("R_cliente");

                entity.HasOne(d => d.REmpNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.REmp)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("R_emp");

                entity.HasOne(d => d.RPromoNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.RPromo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("R_promo");

                entity.HasOne(d => d.RServNavigation)
                    .WithMany(p => p.Cita)
                    .HasForeignKey(d => d.RServ)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("R_serv");
            });

            modelBuilder.Entity<Cliente>(entity =>
            {
                entity.HasKey(e => e.IdCliente)
                    .HasName("PRIMARY");

                entity.ToTable("clientes");

                entity.Property(e => e.IdCliente).HasColumnName("Id_cliente");

                entity.Property(e => e.AppCliente)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("App_cliente");

                entity.Property(e => e.CorreoCliente)
                    .HasMaxLength(45)
                    .HasColumnName("Correo_cliente");

                entity.Property(e => e.NoRecomp).HasColumnName("No_recomp");

                entity.Property(e => e.NoVisitas).HasColumnName("No_visitas");

                entity.Property(e => e.NombCliente)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("Nomb_cliente");

                entity.Property(e => e.TelCliente)
                    .IsRequired()
                    .HasMaxLength(15)
                    .HasColumnName("Tel_cliente");
            });

            modelBuilder.Entity<Empleado>(entity =>
            {
                entity.HasKey(e => e.IdEmp)
                    .HasName("PRIMARY");

                entity.ToTable("empleados");

                entity.Property(e => e.IdEmp).HasColumnName("Id_emp");

                entity.Property(e => e.AppEmp)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("App_emp");

                entity.Property(e => e.Contrasena)
                    .IsRequired()
                    .HasMaxLength(45);

                entity.Property(e => e.CorreoEmp)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("Correo_emp");

                entity.Property(e => e.Estatus)
                    .IsRequired()
                    .HasMaxLength(15);

                entity.Property(e => e.FechaIng)
                    .HasColumnType("date")
                    .HasColumnName("Fecha_ing");

                entity.Property(e => e.NombEmp)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("Nomb_emp");

                entity.Property(e => e.TelEmp)
                    .IsRequired()
                    .HasMaxLength(15)
                    .HasColumnName("Tel_emp");

            
            });

            modelBuilder.Entity<Promocione>(entity =>
            {
                entity.HasKey(e => e.IdPromo)
                    .HasName("PRIMARY");

                entity.ToTable("promociones");

                entity.Property(e => e.IdPromo).HasColumnName("Id_promo");

                entity.Property(e => e.DescripPromo)
                    .IsRequired()
                    .HasColumnName("Descrip_promo");

                entity.Property(e => e.FechaPromo)
                    .HasColumnType("date")
                    .HasColumnName("Fecha_promo");

                entity.Property(e => e.NombPromo)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("Nomb_promo");
            });

            modelBuilder.Entity<Servicio>(entity =>
            {
                entity.HasKey(e => e.IdServ)
                    .HasName("PRIMARY");

                entity.ToTable("servicios");

                entity.Property(e => e.IdServ).HasColumnName("Id_serv");

                entity.Property(e => e.CostoServ).HasColumnName("Costo_serv");

                entity.Property(e => e.DescripServ)
                    .IsRequired()
                    .HasColumnName("Descrip_serv");

                entity.Property(e => e.NombServ)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("Nomb_serv");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
