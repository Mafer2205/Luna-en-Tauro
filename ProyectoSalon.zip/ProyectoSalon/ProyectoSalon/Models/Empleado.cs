﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProyectoSalon.Models
{
    public partial class Empleado
    {
        public Empleado()
        {
            Cita = new HashSet<Cita>();
        }

        public int IdEmp { get; set; }
        public string NombEmp { get; set; }
        public string AppEmp { get; set; }
        public string TelEmp { get; set; }
        public string CorreoEmp { get; set; }
        public string Contrasena { get; set; }
        public DateTime FechaIng { get; set; }
        public string Estatus { get; set; }
        //public string Token { get; set; }

        public virtual ICollection<Cita> Cita { get; set; }
    }
}
