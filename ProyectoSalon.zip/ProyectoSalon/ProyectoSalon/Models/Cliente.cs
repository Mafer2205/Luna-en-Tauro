﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProyectoSalon.Models
{
    public partial class Cliente
    {
        public Cliente()
        {
            Cita = new HashSet<Cita>();
        }

        public int IdCliente { get; set; }
        public string NombCliente { get; set; }
        public string AppCliente { get; set; }
        public string TelCliente { get; set; }
        public string CorreoCliente { get; set; }
        public int NoVisitas { get; set; }
        public int NoRecomp { get; set; }

        public virtual ICollection<Cita> Cita { get; set; }
    }
}
