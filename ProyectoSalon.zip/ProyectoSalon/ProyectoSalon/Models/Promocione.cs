﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProyectoSalon.Models
{
    public partial class Promocione
    {
        public Promocione()
        {
            Cita = new HashSet<Cita>();
        }

        public int IdPromo { get; set; }
        public string NombPromo { get; set; }
        public string DescripPromo { get; set; }
        public DateTime FechaPromo { get; set; }
        public float Descuento { get; set; }

        public virtual ICollection<Cita> Cita { get; set; }
    }
}
