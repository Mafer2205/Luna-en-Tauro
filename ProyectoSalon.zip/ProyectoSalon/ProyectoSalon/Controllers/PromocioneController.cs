﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using proyecto_salon.Services;
using ProyectoSalon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace proyecto_salon.Controllers
{
    public class PromocioneController : ControllerBase
    {
        private readonly IPromocioneService _service;
        private readonly ILogger<PromocioneController> _logger;

        public PromocioneController(IPromocioneService service, ILogger<PromocioneController> logger)
        {
            _service = service;
            _logger = logger;
        }


        //Ver todas las promociones
        [HttpGet("api/promociones")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Promocione>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerPromocione()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            _logger.LogInformation($"{userName} - Ver lista de promociones", null);

            try
            {
                var promocione = _service.GetAll(0, 100);
                return Ok(promocione);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw;
            }
        }


        //buscar promocion determinado
        [HttpGet("api/promociones/{idPromo}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Promocione))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerPromocioneEspecifico(int idPromo)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;


            _logger.LogInformation($"{userName} - Llamo al metodo de ver promocion con id especificado {idPromo}", null);

            try
            {
                var promocione = _service.GetPromocione(idPromo);
                if (promocione != null)
                {
                    return Ok(
                        new
                        {

                            NombPromo = promocione.NombPromo,
                            DescripPromo= promocione.DescripPromo,
                            FechaPromo = promocione.FechaPromo,
                            Descuento = promocione.Descuento
                        }
                    );
                }

                return BadRequest("Promocion no encontrada.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion ", idPromo);
                throw;
            }
        }




        //añadir promocion
        [HttpPost("api/agregarpromociones")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GuardarPromocione([FromBody] Promocione promocione)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Nueva promocion registrada");
                var addpromo = _service.GuardarPromocione(promocione);

                if (addpromo)
                    return Ok();
                else
                    return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante el agregado de {promocione.IdPromo} a la base de datos");
                throw;
            }
        }
    }
}
