﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using proyecto_salon.Services;
using ProyectoSalon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace proyecto_salon.Controllers
{
    public class ServicioController : ControllerBase
    {
        private readonly IServicioService _service;
        private readonly ILogger<ServicioController> _logger;

        public ServicioController(IServicioService service, ILogger<ServicioController> logger)
        {
            _service = service;
            _logger = logger;
        }


        //Ver todos los servicios
        [HttpGet("api/servicios")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Servicio>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerServicios()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            _logger.LogInformation($"{userName} - Ver lista de servicios", null);

            try
            {
                var servicios = _service.GetAll(0, 100);
                return Ok(servicios);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw;
            }
        }


        //buscar servicio determinado
        [HttpGet("api/servicios/{idServ}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Servicio))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerServicioEspecifico(int idServ)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;


            _logger.LogInformation($"{userName} - Llamo al metodo de ver servicio con id especificado {idServ}", null);

            try
            {
                var servicio = _service.GetServicio(idServ);
                if (servicio != null)
                {
                    return Ok(
                        new
                        {

                            NombServ = servicio.NombServ,
                            DescripServ = servicio.DescripServ,
                            CostoServ = servicio.CostoServ
                        }
                    );
                }

                return BadRequest("Servicio no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion ", idServ);
                throw;
            }
        }




        //añadir servicios
        [HttpPost("api/agregarservicios")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GuardarServicio([FromBody] Servicio servicio)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Nuevo servicio registrado");
                var addserv = _service.GuardarServicio(servicio);

                if (addserv)
                    return Ok();
                else
                    return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante el agregado de {servicio.IdServ} a la base de datos");
                throw;
            }
        }



        //actualizar datos de servicio
        [HttpPut("api/actualizarservicio/{Id_serv}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarServicio([FromBody] Servicio servicio, int id_serv)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando servicio con id numero {id_serv}");
                var updatserv = _service.ActualizarServicio(servicio, id_serv);

                if (updatserv)
                    return Ok();
                else
                    return BadRequest("Servicio no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion del servicio {servicio.IdServ}");
                throw;
            }
        }

    }

}