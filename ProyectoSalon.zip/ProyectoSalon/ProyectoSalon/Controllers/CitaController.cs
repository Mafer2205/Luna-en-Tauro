﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using proyecto_salon.Services;
using ProyectoSalon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace proyecto_salon.Controllers
{
    public class CitaController : ControllerBase
    {
        private readonly ICitaService _service;
        private readonly ILogger<CitaController> _logger;

        public CitaController(ICitaService service, ILogger<CitaController> logger)
        {
            _service = service;
            _logger = logger;
        }


        //Ver todas las citas
        [HttpGet("api/citas")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Cita>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerCitas()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            _logger.LogInformation($"{userName} - Ver lista de citas", null);

            try
            {
                var citas = _service.GetAll(0, 100);
                return Ok(citas);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw;
            }
        }

        [HttpGet("api/servicioscitas")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Cita>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Ver()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            _logger.LogInformation($"{userName} - Ver lista de servicios recientes", null);

            try
            {
                var citas = _service.Getb(0, 100);
                return Ok(citas);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw;
            }
        }

        [HttpGet("api/empleadoscitas")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Cita>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult EmpCit()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            _logger.LogInformation($"{userName} - Ver lista de empleados y sus citas", null);

            try
            {
                var citas = _service.Getemp(0, 100);
                return Ok(citas);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw;
            }
        }


        //buscar cita determinada
        [HttpGet("api/citas/{idCita}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Cita))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerCitaEspecifico(int idCita)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;


            _logger.LogInformation($"{userName} - Llamo al metodo de ver cita con id especificado {idCita}", null);

            try
            {
                var cita = _service.GetCita(idCita);
                if (cita != null)
                {
                    return Ok(
                        new
                        {

                            FechaCita = cita.FechaCita,
                            Asistio = cita.Asistio,
                            RCliente = cita.RCliente,
                            RServ = cita.RServ,
                            RPromo = cita.RPromo,
                            REmp = cita.REmp,
                            TotalCita = cita.TotalCita
                        }
                    );
                }

                return BadRequest("Cita no encontrada.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion ", idCita);
                throw;
            }
        }




        //añadir cita
        [HttpPost("api/agregarcitas")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GuardarCita([FromBody] Cita cita)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Nueva cita registrada");
                var addcita= _service.GuardarCita(cita);

                if (addcita)
                    return Ok();
                else
                    return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante el agregado de {cita.IdCita} a la base de datos");
                throw;
            }
        }



        //actualizar datos de cita
        [HttpPut("api/actualizarcita/{Id_cita}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarCita([FromBody] Cita cita, int id_cita)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando cita con id numero {id_cita}");
                var updatcita = _service.ActualizarCita(cita, id_cita);

                if (updatcita)
                    return Ok();
                else
                    return BadRequest("Cita no encontrada.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion de la cita {cita.IdCita}");
                throw;
            }
        }

        [HttpPut("api/actualizarestatus/{Id_cita}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarE([FromBody] Cita cita, int id_cita)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando estatus de cita {id_cita}");
                var updatcita = _service.ActualizarE(cita, id_cita);

                if (updatcita)
                    return Ok();
                else
                    return BadRequest("Cita no encontrada.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion de la cita {cita.IdCita}");
                throw;
            }
        }

    }

}