﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using proyecto_salon.Services;
using ProyectoSalon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace proyecto_salon.Controllers
{
    public class ClienteController : ControllerBase
    {
        private readonly IClienteService _service;
        private readonly ILogger<ClienteController> _logger;

        public ClienteController(IClienteService service, ILogger<ClienteController> logger)
        {
            _service = service;
            _logger = logger;
        }


        //Ver todos los clientes
        [HttpGet("api/clientes")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Cliente>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerCliente()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            _logger.LogInformation($"{userName} - Ver lista de clientes", null);

            try
            {
                var clientes = _service.GetAll(0, 100);
                return Ok(clientes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw;
            }
        }


        //buscar cliente determinado
        [HttpGet("api/clientes/{idCliente}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Cliente))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerClienteEspecifico(int idCliente)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;


            _logger.LogInformation($"{userName} - Llamo al metodo de ver cliente con id especificado {idCliente}", null);

            try
            {
                var cliente = _service.GetCliente(idCliente);
                if (cliente != null)
                {
                    return Ok(
                        new
                        {

                            NombCliente = cliente.NombCliente,
                            AppCliente = cliente.AppCliente,
                            TelCliente = cliente.TelCliente,
                            CorreoCliente = cliente.CorreoCliente,
                            NoVisitas = cliente.NoVisitas,
                            NoRecomp = cliente.NoRecomp
                        }
                    );
                }

                return BadRequest("Cliente no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion ", idCliente);
                throw;
            }
        }




        //añadir clientes
        [HttpPost("api/agregarclientes")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GuardarCliente([FromBody] Cliente cliente)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Nuevo cliente registrado");
                var addcli = _service.GuardarCliente(cliente);

                if (addcli)
                    return Ok();
                else
                    return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante el agregado de {cliente.IdCliente} a la base de datos");
                throw;
            }
        }



        //actualizar datos de cliente
        [HttpPut("api/actualizarcliente/{Id_cliente}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarCliente([FromBody] Cliente cliente, int id_cliente)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando cliente con id numero {id_cliente}");
                var updatemp = _service.ActualizarCliente(cliente, id_cliente);

                if (updatemp)
                    return Ok();
                else
                    return BadRequest("Cliente no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion del cliente {cliente.IdCliente}");
                throw;
            }
        }


        [HttpPut("api/actualizarrecompensa/{Id_cliente}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarRecomp([FromBody] Cliente cliente, int id_cliente)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando cliente con id numero {id_cliente}");
                var updatemp = _service.ActualizarRecomp(cliente, id_cliente);

                if (updatemp)
                    return Ok();
                else
                    return BadRequest("Cliente no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion del cliente {cliente.IdCliente}");
                throw;
            }
        }

    }

}