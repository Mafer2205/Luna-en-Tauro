﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProyectoSalon.Models;
using ProyectoSalon.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProyectoSalon.Controllers
{
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly IUserService _service;
        private readonly ILogger<UserController> _logger;

        public UserController(ILogger<UserController> logger, IUserService service)
        {
            _service = service;
            _logger = logger;
        }


        [HttpGet("/users/")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<User>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetAll()
        {
            try
            {
                var users = _service.GetAll();
                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Un error ocurrio buscando la lista de usuarios");
                throw;
            }
        }

        [HttpGet("/users/{userId}")]
        public IActionResult GetUser(string userId)
        {
            return null;
        }

        [AllowAnonymous]
        [HttpPost("/api/empleados/autenticacion")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(User))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Authenticate([FromBody] User user)
        {
            try
            {
                _logger.LogInformation($"Autenticando usuario {user.UserName}");
                var userData = _service.Authenticate(user.UserName, user.Password);

                if (userData == null)
                {
                    _logger.LogInformation("Usuario o contraseña es incorrecto!");
                    return BadRequest("Usuario o contraseña incorrecto!");
                }

                _logger.LogInformation($"Autenticacion hecha, usuario: {user.UserName}");
                return Ok(userData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Un error ocurrio en la identificacion del usuario {user.UserName}");
                throw;
            }
        }
    }
}