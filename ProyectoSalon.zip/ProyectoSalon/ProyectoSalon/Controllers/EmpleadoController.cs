﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProyectoSalon.Models;
using ProyectoSalon.Services;
using System;
using System.Collections.Generic;
using System.Security.Claims;


namespace ProyectoSalon.Controllers
{

    public class EmpleadoController : ControllerBase
    {
        private readonly IEmpleadoService _service;
        private readonly ILogger<EmpleadoController> _logger;

        public EmpleadoController(IEmpleadoService service, ILogger<EmpleadoController> logger)
        {
            _service = service;
            _logger = logger;
        }


        //Ver todos los empleados
        [HttpGet("api/empleados")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Empleado>))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerEmpleados ()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName  = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
            
            _logger.LogInformation($"{userName} - Ver lista de empleados", null);

            try
            {
                var empleados  = _service.GetAll(0, 100);
                return Ok(empleados);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion");
                throw; 
            }
        }


        //buscar empleado determinado
        [HttpGet("api/empleados/{idEmp}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Empleado))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult VerEmpleadoEspecifico(int idEmp)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName  = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
      

            _logger.LogInformation($"{userName} - Llamo al metodo de ver empleado con id especificado {idEmp}", null);

            try
            {
                var empleado  = _service.GetEmpleado(idEmp);
                if (empleado != null)
                {
                    return Ok(
                        new
                        {
                          
                            NombEmp  = empleado.NombEmp,
                            AppEmp  = empleado.AppEmp,
                            TelEmp = empleado.TelEmp,
                            CorreoEmp  = empleado.CorreoEmp,
                            Contrasena = empleado.Contrasena,
                            FechaIng   = empleado.FechaIng,
                            Estatus  = empleado.Estatus
                        }
                    );
                }

                return BadRequest("Empleado no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la extraccion de informacion ", idEmp);
                throw;
            }
        }




        //añadir empleados
        [HttpPost("api/agregarempleados")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GuardarEmpleado ([FromBody] Empleado empleado)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName  = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Nuevo empleado registrado");
                var addemp = _service.GuardarEmpleado(empleado);

                if (addemp)
                    return Ok();
                else
                    return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante el agregado de {empleado.IdEmp} a la base de datos");
                throw;
            }
        }



        //actualizar datos de empleado
        [HttpPut("api/actualizarempleado/{Id_emp}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarEmpleado([FromBody] Empleado empleado, int id_emp)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando empleado con id numero {id_emp}");
                var updatemp = _service.ActualizarEmpleado(empleado, id_emp);

                if (updatemp)
                    return Ok();
                else
                    return BadRequest("Empleado no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion del empleado {empleado.IdEmp}");
                throw;
            }
        }


        [HttpPut("api/actualizarempleadoestatus/{Id_emp}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ActualizarEst([FromBody] Empleado empleado, int id_emp)
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userName = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

            try
            {
                _logger.LogInformation($"{userName} - Actualizando estatus de empleado {id_emp}");
                var updatemp = _service.ActualizarEst(empleado, id_emp);

                if (updatemp)
                    return Ok();
                else
                    return BadRequest("Empleado no encontrado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{userName} - Error durante la actulizacion de informacion del empleado {empleado.IdEmp}");
                throw;
            }
        }


    }

}