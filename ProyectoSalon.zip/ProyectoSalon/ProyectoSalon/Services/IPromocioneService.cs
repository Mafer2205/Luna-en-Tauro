﻿using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Services
{
    public interface IPromocioneService
    {
        IEnumerable GetAll(int v1, int v2);
        Promocione GetPromocione(int idpromo);
        bool GuardarPromocione(Promocione promo);
    }
}
