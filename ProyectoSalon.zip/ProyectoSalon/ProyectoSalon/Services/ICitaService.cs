﻿using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Services
{
    public interface ICitaService
    {
        IEnumerable GetAll(int v1, int v2);
        IEnumerable Getb(int v1, int v2);
        IEnumerable Getemp(int v1, int v2);
        Cita GetCita(int idcita);
        bool GuardarCita(Cita cita);
        bool ActualizarCita(Cita cita, int idcita);
        bool ActualizarE(Cita cita, int idcita);
    }
}
