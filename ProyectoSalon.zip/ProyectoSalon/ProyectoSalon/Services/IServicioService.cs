﻿using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Services
{
    public interface IServicioService
    {
        IEnumerable GetAll(int v1, int v2);
        Servicio GetServicio(int idserv);
        bool GuardarServicio(Servicio servicio);
        bool ActualizarServicio(Servicio servicio, int idserv);
    }
}
