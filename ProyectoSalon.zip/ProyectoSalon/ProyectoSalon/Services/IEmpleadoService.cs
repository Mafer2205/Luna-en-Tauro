﻿
using ProyectoSalon.Models;
using System.Collections;


namespace ProyectoSalon.Services
{
    public interface IEmpleadoService
    {
        IEnumerable GetAll(int v1, int v2);
        Empleado GetEmpleado(int idemp);
        bool GuardarEmpleado(Empleado empleado);
        bool ActualizarEmpleado(Empleado empleado, int idemp);
        bool ActualizarEst(Empleado empleado, int idemp);

    }
}
