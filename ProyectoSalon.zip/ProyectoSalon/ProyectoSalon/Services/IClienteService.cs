﻿using ProyectoSalon.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proyecto_salon.Services
{
    public interface IClienteService
    {
        IEnumerable GetAll(int v1, int v2);
        Cliente GetCliente(int idcliente);
        bool GuardarCliente(Cliente cliente);
        bool ActualizarCliente(Cliente cliente, int idcliente);
        bool ActualizarRecomp(Cliente cliente, int idcliente);

    }
}
